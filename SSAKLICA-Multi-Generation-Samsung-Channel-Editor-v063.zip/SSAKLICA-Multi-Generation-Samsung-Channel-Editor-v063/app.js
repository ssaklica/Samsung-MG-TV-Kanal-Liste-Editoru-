/* Samsung Channel Editor - browser-only prototype v0.6.3
 * Phase 2: automatic Samsung format detection
 * - Modern Samsung SQLite/TKGS (existing v0.5.1 engine)
 * - Legacy Samsung SCM multi-list: map-CableD 320-byte + map-SateD 168-byte profiles (UE46F6400 _1201 sample)
 */
(() => {
  'use strict';

  const els = {
    channelFile: document.getElementById('channelFile'), fileInfo: document.getElementById('fileInfo'), formatInfo: document.getElementById('formatInfo'), status: document.getElementById('status'),
    workspace: document.getElementById('workspace'), tabs: document.getElementById('tabs'), search: document.getElementById('search'),
    showSystem: document.getElementById('showSystem'), showSystemWrap: document.getElementById('showSystemWrap'), showHidden: document.getElementById('showHidden'), showHiddenWrap: document.getElementById('showHiddenWrap'),
    body: document.getElementById('channelBody'), rowTemplate: document.getElementById('rowTemplate'), sourceSummary: document.getElementById('sourceSummary'), changeSummary: document.getElementById('changeSummary'),
    undoAll: document.getElementById('undoAll'), exportFile: document.getElementById('exportFile'), normalizeOrder: document.getElementById('normalizeOrder'),
    hideSelected: document.getElementById('hideSelected'), restoreSelected: document.getElementById('restoreSelected'), selectAll: document.getElementById('selectAll'),
    verification: document.getElementById('verification'), warningNote: document.getElementById('warningNote'), modeHint: document.getElementById('modeHint'), typeFilter: document.getElementById('typeFilter')
  };

  const state = {
    SQL: null,
    mode: null, // modern | legacy-scm
    archive: null,
    archiveBytes: null,
    fileName: '',
    sourceName: '',
    selected: new Set(),
    modern: {
      db: { tkgs: null, dvbs: null },
      originalBytes: { tkgs: null, dvbs: null },
      channels: { tkgs: [], dvbs: [] },
      sequenceDirty: { tkgs: false, dvbs: false }
    },
    legacy: {
      model: '',
      sources: {} // scm-cable / scm-sate -> {mapName,label,profile,recordSize,recordCount,originalMapBytes,channels,sequenceDirty}
    }
  };

  const LEGACY_PROFILES = [
    // Samsung E/F/H/J satellite digital profile, confirmed with the supplied UE46F6400 _1201 fixture.
    { id: 'EFHJ-SATE-168', mapNames: ['map-SateD'], recordSize: 168, numberOffset: 0, numberLength: 2, inUseOffset: 7, inUseMask: 0x01, deleteMode: 'clearInUse', lockOffset: 13, lockMask: 0x01, serviceTypeOffset: 14, serviceIdOffset: 16, tsidOffset: 24, onidOffset: 28, nameOffset: 36, nameBytes: 100, encryptedOffset: 136, encryptedMask: 0x01, providerOffset: 138, checksumOffset: 167, nameEncoding: 'utf16be' },
    // Classic Samsung digital map profile. SamsChannelEditor documents default record sizes 292/320;
    // the supplied UE46F6400 map-CableD is 1000 x 320 and matches these field offsets.
    { id: 'LEGACY-DIGITAL-320', mapNames: ['map-CableD','map-AirD'], recordSize: 320, numberOffset: 0, numberLength: 2, inUseOffset: null, deletedOffset: 8, deletedMask: 0x01, deleteMode: 'deletedBit', serviceTypeOffset: 15, serviceIdOffset: 6, tsidOffset: 48, onidOffset: 32, nameOffset: 64, nameBytes: 100, encryptedOffset: 24, encryptedMask: 0x01, lockOffset: 31, lockMask: 0x01, checksumOffset: 319, nameEncoding: 'utf16be' }
  ];

  function setStatus(text, type = 'info') { els.status.textContent = text; els.status.className = `status ${type}`; }
  function escapeHtml(s) { return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
  function bytesEqual(a, b) { if (!a || !b || a.length !== b.length) return false; for (let i=0;i<a.length;i++) if (a[i]!==b[i]) return false; return true; }
  function copyBytes(bytes) { return new Uint8Array(bytes); }
  function downloadBlob(blob, fileName) { const a=document.createElement('a'), url=URL.createObjectURL(blob); a.href=url; a.download=fileName; document.body.appendChild(a); a.click(); a.remove(); setTimeout(()=>URL.revokeObjectURL(url),2000); }

  // ---------- Samsung text helpers (modern SQLite) ----------
  function swapUtf16Bytes(text) {
    if (!text) return '';
    let out='';
    for (let i=0;i<text.length;i++) { const c=text.charCodeAt(i); out += String.fromCharCode(((c&0xff)<<8)|((c>>>8)&0xff)); }
    return out.replace(/\u0000+$/g,'');
  }
  function decodeSamsungBytes(value) {
    const bytes=value instanceof Uint8Array?value:value instanceof ArrayBuffer?new Uint8Array(value):ArrayBuffer.isView(value)?new Uint8Array(value.buffer,value.byteOffset,value.byteLength):null;
    if (!bytes) return null;
    if (!bytes.length) return '';
    const slice=bytes.subarray(0,bytes.length-(bytes.length%2));
    const decode=little=>{ let out=''; for(let i=0;i<slice.length;i+=2){ const code=little?(slice[i]|(slice[i+1]<<8)):((slice[i]<<8)|slice[i+1]); if(code) out+=String.fromCharCode(code); } return out.replace(/\u0000+$/g,'').trim(); };
    const be=decode(false), le=decode(true);
    const score=t=>{ if(!t)return-999; let good=0,bad=0; for(const ch of t.slice(0,80)){ const c=ch.charCodeAt(0); if((c>=0x20&&c<=0x7e)||(c>=0x00c0&&c<=0x024f)||'ÇĞİÖŞÜçğıöşü₺'.includes(ch))good+=2; else if(c<0x20||c>=0x3000)bad+=3; else good+=.25; } return good-bad; };
    return score(be)>=score(le)?be:le;
  }
  function cleanSamsungText(value) {
    if(value==null)return '';
    const decoded=decodeSamsungBytes(value); if(decoded!==null)return decoded;
    const text=String(value); if(!text)return '';
    const sample=Array.from(text).slice(0,12); const suspicious=sample.length&&sample.filter(ch=>ch.charCodeAt(0)>0x1000).length/sample.length>.45;
    return suspicious?swapUtf16Bytes(text):text;
  }
  function queryObjects(db, sql, params=[]) { const stmt=db.prepare(sql); try{ stmt.bind(params); const rows=[]; while(stmt.step()) rows.push(stmt.getAsObject()); return rows; } finally{ stmt.free(); } }

  // ---------- Legacy SCM helpers ----------
  function readU16LE(bytes, offset) { return bytes[offset] | (bytes[offset+1] << 8); }
  function writeU16LE(bytes, offset, value) { bytes[offset]=value&0xff; bytes[offset+1]=(value>>>8)&0xff; }
  function readU16LEAt(bytes, base, rel) { return readU16LE(bytes, base+rel); }
  function legacyChecksum(bytes, base, recordSize) { let sum=0; for(let i=0;i<recordSize-1;i++) sum=(sum+bytes[base+i])&0xff; return sum; }
  function writeLegacyChecksum(bytes, base, profile) { if(profile.checksumOffset==null)return; bytes[base+profile.checksumOffset]=legacyChecksum(bytes,base,profile.recordSize); }
  function legacyServiceTypeLabel(v){ return ({1:'TV',2:'Radyo',12:'Data',25:'HD'})[v] || `Tip ${v}`; }
  function modernServiceTypeLabel(v){ return legacyServiceTypeLabel(Number(v)); }
  function decodeUtf16BE(bytes, offset, byteLength) {
    let out=''; const end=Math.min(bytes.length, offset+byteLength);
    for(let i=offset;i+1<end;i+=2){ const code=(bytes[i]<<8)|bytes[i+1]; if(code===0)break; if(code===0xffff)break; out+=String.fromCharCode(code); }
    return out.trimEnd();
  }
  function encodeUtf16BEInto(bytes, offset, byteLength, text) {
    bytes.fill(0, offset, offset+byteLength);
    const maxUnits=Math.max(0, Math.floor(byteLength/2)-1); // reserve terminator
    const chars=Array.from(text).slice(0,maxUnits);
    let pos=offset;
    for(const ch of chars){ const code=ch.charCodeAt(0); bytes[pos++]=(code>>>8)&0xff; bytes[pos++]=code&0xff; }
  }
  function isPlausibleLegacyName(name) {
    if(!name || name.length>60)return false;
    let good=0,bad=0;
    for(const ch of name){ const c=ch.charCodeAt(0); if(c>=0x20 && c!==0xfffd)good++; else bad+=3; }
    return good>0 && good>=bad;
  }
  function detectLegacyProfile(mapName, mapBytes) {
    let best=null;
    for(const profile of LEGACY_PROFILES){
      if(!profile.mapNames.includes(mapName) || mapBytes.length % profile.recordSize !== 0) continue;
      const count=mapBytes.length/profile.recordSize;
      let plausible=0, tested=0;
      for(let i=0;i<Math.min(count,180);i++){
        const base=i*profile.recordSize, num=readU16LE(mapBytes,base+profile.numberOffset);
        if(num<=0 || num===0xffff) continue;
        const name=decodeUtf16BE(mapBytes,base+profile.nameOffset,profile.nameBytes);
        tested++; if(isPlausibleLegacyName(name)&&num<20000)plausible++;
      }
      const score=tested?plausible/tested:0;
      if(score>.70 && (!best||score>best.score)) best={profile,score,count};
    }
    return best;
  }
  function parseCloneInfo(bytes) {
    let start=0; for(let i=0;i<Math.min(bytes.length,8);i++){ if(bytes[i]===0){start=i+1;break;} }
    let s=''; for(let i=start;i<bytes.length;i++){ if(bytes[i]===0)break; if(bytes[i]>=0x20&&bytes[i]<0x7f)s+=String.fromCharCode(bytes[i]); }
    return s || 'Bilinmeyen Samsung';
  }
  function legacySource(source=state.sourceName){ return state.legacy.sources[source]; }
  function loadLegacyChannels(source) {
    const L=legacySource(source), p=L.profile, bytes=L.originalMapBytes, rows=[], activeRecordIndices=[];
    for(let i=0;i<L.recordCount;i++){
      const base=i*p.recordSize, major=readU16LE(bytes,base+p.numberOffset);
      const inUse=p.inUseOffset==null ? (major>0 && major!==0xffff) : ((bytes[base+p.inUseOffset] & p.inUseMask)!==0);
      if(!inUse || major<=0 || major===0xffff) continue;
      const preDeleted=p.deletedOffset!=null && ((bytes[base+p.deletedOffset]&p.deletedMask)!==0);
      if(preDeleted) continue;
      activeRecordIndices.push(i);
      const name=decodeUtf16BE(bytes,base+p.nameOffset,p.nameBytes);
      if(!name || !isPlausibleLegacyName(name)) continue;
      const serviceType=p.serviceTypeOffset==null?null:bytes[base+p.serviceTypeOffset];
      const sid=p.serviceIdOffset==null?null:readU16LE(bytes,base+p.serviceIdOffset);
      const tsid=p.tsidOffset==null?null:readU16LE(bytes,base+p.tsidOffset);
      const onid=p.onidOffset==null?null:readU16LE(bytes,base+p.onidOffset);
      const encrypted=p.encryptedOffset==null?false:((bytes[base+p.encryptedOffset]&p.encryptedMask)!==0);
      rows.push({
        key:`${source}:rec:${i}`, recordIndex:i, originalMajor:major, major, originalName:name, srvName:name,
        uiOrder:major, originalUiOrder:major, hiddenByEditor:false, originalHidden:false,
        deletedByEditor:false, originalDeleted:false,
        provName:L.label, sourceLabel:L.label, serviceTypeLabel:serviceType==null?'Legacy SCM':legacyServiceTypeLabel(serviceType), freq:null, sr:null, pol:null,
        onid, tsid, progNum:sid, scrambled:encrypted, serviceType
      });
    }
    rows.sort((a,b)=>a.originalMajor-b.originalMajor||a.recordIndex-b.recordIndex);
    L.channels=rows; L.activeRecordIndices=activeRecordIndices; L.sequenceDirty=false;
  }
  function legacyLabelForMap(mapName){ return mapName==='map-CableD'?'TV / Dijital Kablo':mapName==='map-SateD'?'Uydu':'Dijital'; }
  async function addLegacySource(zip,mapName,sourceId){
    const f=zip.file(mapName); if(!f)return null;
    const bytes=new Uint8Array(await f.async('arraybuffer')), det=detectLegacyProfile(mapName,bytes);
    if(!det)return null;
    state.legacy.sources[sourceId]={sourceId,mapName,label:legacyLabelForMap(mapName),profile:det.profile,recordSize:det.profile.recordSize,recordCount:det.count,originalMapBytes:copyBytes(bytes),channels:[],activeRecordIndices:[],sequenceDirty:false};
    loadLegacyChannels(sourceId);
    return state.legacy.sources[sourceId];
  }

  // ---------- Common channel model ----------
  const polLabel=v=>({0:'H',1:'V',2:'L',3:'R'})[v]??(v==null?'—':String(v));
  const formatFreq=f=>f==null?'—':f>=1000000?`${(f/1000).toFixed(0)} MHz`:String(f);
  function modernIsSystem(source,ch){ return source==='dvbs'&&Number(ch.originalMajor)>=10000; }
  function isSystemChannel(ch){ return state.mode==='modern'&&modernIsSystem(state.sourceName,ch); }
  function getChannels(source=state.sourceName) { return state.mode==='modern'?state.modern.channels[source]:(legacySource(source)?.channels||[]); }
  function normalChannels(source=state.sourceName) {
    return getChannels(source).filter(ch=>!isSystemForSource(source,ch) && !(state.mode==='legacy-scm'&&ch.deletedByEditor)).sort((a,b)=>a.uiOrder-b.uiOrder||String(a.key||a.srvKey).localeCompare(String(b.key||b.srvKey)));
  }
  function isSystemForSource(source,ch){ return state.mode==='modern'&&modernIsSystem(source,ch); }
  function currentKey(ch){ return String(ch.key??ch.srvKey); }
  function visibleChannels(){
    const term=els.search.value.trim().toLocaleLowerCase('tr-TR'), typeValue=els.typeFilter?.value||'';
    return getChannels().filter(ch=>els.showSystem.checked||!isSystemChannel(ch))
      .filter(ch=>state.mode==='legacy-scm' ? (els.showHidden.checked||!ch.deletedByEditor) : (els.showHidden.checked||!ch.hiddenByEditor))
      .filter(ch=>!typeValue||String(ch.serviceTypeLabel||modernServiceTypeLabel(ch.srvType||ch.serviceType))===typeValue)
      .filter(ch=>!term||`${ch.uiOrder} ${ch.srvName} ${ch.provName||''} ${ch.serviceTypeLabel||''} ${ch.sourceLabel||''}`.toLocaleLowerCase('tr-TR').includes(term))
      .sort((a,b)=>a.uiOrder-b.uiOrder||currentKey(a).localeCompare(currentKey(b)));
  }
  function channelChangedFor(source,ch){
    const order=!isSystemForSource(source,ch)&&ch.uiOrder!==ch.originalUiOrder;
    return order||ch.srvName!==ch.originalName||ch.hiddenByEditor!==ch.originalHidden||Boolean(ch.deletedByEditor)!==Boolean(ch.originalDeleted);
  }
  function sourceSequenceDirty(source){ return state.mode==='modern'?state.modern.sequenceDirty[source]:Boolean(legacySource(source)?.sequenceDirty); }
  function setSourceSequenceDirty(source,v){ if(state.mode==='modern')state.modern.sequenceDirty[source]=v; else if(legacySource(source))legacySource(source).sequenceDirty=v; }
  function sourceHasChanges(source){ return sourceSequenceDirty(source)||getChannels(source).some(ch=>channelChangedFor(source,ch)); }
  function totalChanges(){
    if(state.mode==='modern') return ['tkgs','dvbs'].reduce((n,s)=>n+state.modern.channels[s].filter(ch=>channelChangedFor(s,ch)).length+(state.modern.sequenceDirty[s]?1:0),0);
    return Object.keys(state.legacy.sources).reduce((n,src)=>n+getChannels(src).filter(ch=>channelChangedFor(src,ch)).length+(sourceSequenceDirty(src)?1:0),0);
  }

  // ---------- Modern loader ----------
  function loadModernChannels(source){
    const db=state.modern.db[source], isTkgs=source==='tkgs';
    const rows=queryObjects(db,`
      SELECT s.srvId,CAST(s.srvId AS TEXT) AS srvKey,s.major,s.progNum,s.srvName,s.srvType,s.tsid,s.scrambled,s.hidden,s.hideGuide,s.lockMode,s.modifiedByUser,
             s.elim,s.mem,s.numSel,s.sync,c.freq,c.sr,c.pol,d.onid,d.lcn,d.provId,p.provName
             ${isTkgs?', so.tkgsSrvLocator AS tkgsSrvLocator':', NULL AS tkgsSrvLocator'}
      FROM SRV s LEFT JOIN CHNL c ON c.chId=s.chId LEFT JOIN SRV_DVB d ON d.srvId=s.srvId LEFT JOIN PROV p ON p.provId=d.provId
      ${isTkgs?'LEFT JOIN SRV_SO so ON so.srvId=s.srvId':''} ORDER BY s.major,s.srvId`);
    const mapped=rows.map(r=>({...r, serviceTypeLabel:modernServiceTypeLabel(r.srvType), key:String(r.srvKey), srvKey:String(r.srvKey), srvName:cleanSamsungText(r.srvName), provName:cleanSamsungText(r.provName), originalName:cleanSamsungText(r.srvName), originalMajor:Number(r.major), major:Number(r.major), hiddenByEditor:Boolean(r.hidden), originalHidden:Boolean(r.hidden), uiOrder:null, originalUiOrder:null}));
    const normal=mapped.filter(ch=>!modernIsSystem(source,ch)).sort((a,b)=>a.originalMajor-b.originalMajor||String(a.srvKey).localeCompare(String(b.srvKey)));
    normal.forEach((ch,i)=>{ch.uiOrder=i+1;ch.originalUiOrder=i+1;});
    mapped.filter(ch=>modernIsSystem(source,ch)).forEach(ch=>{ch.uiOrder=ch.originalMajor;ch.originalUiOrder=ch.originalMajor;});
    state.modern.channels[source]=mapped; state.modern.sequenceDirty[source]=false;
  }
  function validateModernSchema(db,label){
    const tables=new Set(queryObjects(db,"SELECT name FROM sqlite_master WHERE type='table'").map(r=>String(r.name)));
    for(const t of ['SRV','CHNL','SRV_DVB']) if(!tables.has(t)) throw new Error(`${label}: gerekli tablo bulunamadı: ${t}`);
  }

  // ---------- UI ----------
  function rebuildTypeFilter(){
    if(!els.typeFilter)return;
    const prev=els.typeFilter.value;
    const types=[...new Set(getChannels().map(ch=>state.mode==='legacy-scm'?(ch.serviceTypeLabel||'Legacy SCM'):modernServiceTypeLabel(ch.srvType)).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'tr'));
    els.typeFilter.replaceChildren(new Option('Tüm tipler',''));
    for(const t of types) els.typeFilter.add(new Option(t,t));
    if(types.includes(prev)) els.typeFilter.value=prev;
  }
  function buildTabs(){
    els.tabs.replaceChildren();
    const items=state.mode==='modern'?[['tkgs','TKGS'],['dvbs','DVB-S']]:Object.entries(state.legacy.sources).map(([id,L])=>[id,`${L.label} (SCM)`]);
    for(const [source,label] of items){ const b=document.createElement('button'); b.className='tab'+(source===state.sourceName?' active':''); b.dataset.source=source; b.textContent=label; b.addEventListener('click',()=>{state.sourceName=source;state.selected.clear();buildTabs();rebuildTypeFilter();render();}); els.tabs.appendChild(b); }
  }
  function updateModeUi(){
    const legacy=state.mode==='legacy-scm';
    els.showHiddenWrap.classList.remove('hidden'); els.showHiddenWrap.querySelector('span').textContent=legacy?'Silinenleri göster':'Gizlenenleri göster';
    els.showSystemWrap.classList.toggle('hidden',legacy);
    els.hideSelected.textContent=legacy?'Seçilenleri Sil':'Seçilenleri Gizle';
    els.restoreSelected.textContent=legacy?'Seçilenleri Geri Getir':'Seçilenleri Geri Getir';
    els.hideSelected.classList.remove('hidden'); els.restoreSelected.classList.remove('hidden'); els.selectAll.disabled=false;
    els.modeHint.textContent=legacy
      ? 'Legacy SCM: kanal sırası/adı düzenlenebilir; seçilen kayıtlar formatın kendi silme/aktiflik bayrağıyla devre dışı bırakılır ve record checksum yeniden hesaplanır.'
      : 'Bir kanala hedef sıra numarasını yaz; diğer kanallar otomatik kayar. TKGS metadata alanları korunur.';
    els.warningNote.innerHTML=legacy
      ? '<strong>Legacy SCM Faz 2.3:</strong> <code>map-CableD / 320-byte</code> ve <code>map-SateD / 168-byte</code> listelerinde sıralama, ad değiştirme ve silme desteklenir. Silmede <code>map-CableD</code> için Deleted biti, <code>map-SateD</code> için InUse biti kullanılır; kayıt fiziksel konumunda korunur ve checksum yeniden hesaplanıp doğrulanır.'
      : '<strong>Modern Samsung:</strong> sıralama <code>SRV.major</code> alanına 1..N olarak yazılır. TKGS’de <code>lcn</code> ve <code>tkgsSrvLocator</code> korunur. Gizleme deneysel olup servis kaydı fiziksel olarak silinmez. Final ZIP tekrar açılarak doğrulanır.';
  }
  function updateChangeUi(){
    const count=totalChanges(); els.changeSummary.textContent=`${count} değişiklik`; els.changeSummary.classList.toggle('dirty',count>0); els.undoAll.disabled=count===0; els.exportFile.disabled=!state.archive||count===0;
    const selected=getChannels().filter(ch=>state.selected.has(currentKey(ch))&&!isSystemChannel(ch));
    if(state.mode==='modern'){
      els.hideSelected.disabled=!selected.some(ch=>!ch.hiddenByEditor); els.restoreSelected.disabled=!selected.some(ch=>ch.hiddenByEditor);
    } else {
      els.hideSelected.disabled=!selected.some(ch=>!ch.deletedByEditor); els.restoreSelected.disabled=!selected.some(ch=>ch.deletedByEditor);
    }
  }
  function render(){
    els.body.replaceChildren(); const rows=visibleChannels(), all=getChannels();
    if(state.mode==='modern'){
      const systemCount=all.filter(ch=>isSystemChannel(ch)).length, hiddenCount=all.filter(ch=>ch.hiddenByEditor&&!isSystemChannel(ch)).length;
      els.sourceSummary.textContent=`${state.sourceName.toUpperCase()} · ${normalChannels().length} kanal${hiddenCount?` · ${hiddenCount} gizli`:''}${systemCount?` · ${systemCount} sistem servisi`:''}`;
    } else { const L=legacySource(),del=all.filter(ch=>ch.deletedByEditor).length; els.sourceSummary.textContent=`Legacy SCM · ${state.legacy.model} · ${L.label} · ${normalChannels().length} aktif${del?` · ${del} silinecek`:''} · ${L.mapName} · ${L.recordSize} byte/record`; }

    for(const ch of rows){
      const frag=els.rowTemplate.content.cloneNode(true), tr=frag.querySelector('tr'); tr.dataset.key=currentKey(ch); tr.classList.toggle('changed',channelChangedFor(state.sourceName,ch)); tr.classList.toggle('hidden-channel',ch.hiddenByEditor||ch.deletedByEditor); tr.classList.toggle('deleted-channel',Boolean(ch.deletedByEditor));
      const sel=frag.querySelector('.row-select'); sel.checked=state.selected.has(currentKey(ch)); sel.disabled=isSystemChannel(ch); sel.addEventListener('change',()=>{sel.checked?state.selected.add(currentKey(ch)):state.selected.delete(currentKey(ch));updateChangeUi();updateSelectAllState();});
      const num=frag.querySelector('.channel-number'); num.value=ch.uiOrder; num.disabled=isSystemChannel(ch)||Boolean(ch.deletedByEditor); num.addEventListener('change',()=>moveToPosition(ch,num));
      const name=frag.querySelector('.channel-name-input'); name.value=ch.srvName; name.disabled=isSystemChannel(ch)||Boolean(ch.deletedByEditor); name.maxLength=state.mode==='legacy-scm'?49:80;
      name.addEventListener('change',()=>{ const value=name.value.trim(); if(!value){name.value=ch.srvName;setStatus('Kanal adı boş bırakılamaz.','error');return;} if(state.mode==='legacy-scm'&&Array.from(value).length>49){name.value=ch.srvName;setStatus('Legacy SCM kanal adı en fazla 49 karakter olabilir.','error');return;} ch.srvName=value; setStatus(`${ch.originalName} kanal adı “${value}” olarak değiştirildi.`,'ok'); render(); });
      frag.querySelector('.state').textContent=state.mode==='legacy-scm'?(ch.deletedByEditor?'Silinecek':'Aktif'):(ch.hiddenByEditor?'Gizli':'Aktif');
      frag.querySelector('.type').textContent=state.mode==='legacy-scm'?(ch.serviceTypeLabel||'—'):modernServiceTypeLabel(ch.srvType);
      frag.querySelector('.provider').textContent=state.mode==='legacy-scm'?`${ch.sourceLabel||legacySource().label} · Record ${ch.recordIndex}`:(ch.provName||'—');
      frag.querySelector('.frequency').textContent=formatFreq(ch.freq); frag.querySelector('.symbol-rate').textContent=ch.sr&&ch.sr!==65535?ch.sr:'—'; frag.querySelector('.polarization').textContent=polLabel(ch.pol);
      frag.querySelector('.onid').textContent=ch.onid??'—'; frag.querySelector('.tsid').textContent=ch.tsid??'—'; frag.querySelector('.sid').textContent=ch.progNum??'—'; frag.querySelector('.scrambled').textContent=ch.scrambled?'Evet':'Hayır';
      els.body.appendChild(frag);
    }
    updateSelectAllState(); updateChangeUi();
  }
  function renumberUi(list){list.forEach((ch,i)=>{ch.uiOrder=i+1;});}
  function moveToPosition(ch,input){
    if(isSystemChannel(ch)){input.value=ch.uiOrder;return;}
    const list=normalChannels(), target=Number.parseInt(input.value,10); if(!Number.isInteger(target)||target<1||target>list.length){input.value=ch.uiOrder;setStatus(`Hedef sıra 1–${list.length} aralığında olmalıdır.`,'error');return;}
    const idx=list.indexOf(ch); if(idx<0)return; list.splice(idx,1); list.splice(target-1,0,ch); renumberUi(list); setSourceSequenceDirty(state.sourceName,true); setStatus(`${ch.srvName} ${target}. sıraya taşındı.`,'ok'); render();
  }
  function normalizeOrder(){renumberUi(normalChannels());setSourceSequenceDirty(state.sourceName,true);setStatus(`${normalChannels().length} kanal export sırasında 1..N olarak yazılacak.`,'ok');render();}
  function setSelectedHidden(hidden){ if(state.mode!=='modern')return; const selected=getChannels().filter(ch=>state.selected.has(currentKey(ch))&&!isSystemChannel(ch)); if(!selected.length)return; selected.forEach(ch=>{ch.hiddenByEditor=hidden;}); state.selected.clear(); setStatus(`${selected.length} kanal ${hidden?'gizlenecek':'yeniden görünür yapılacak'} şekilde işaretlendi.${state.sourceName==='tkgs'?' TKGS bu davranışı TV tarafında değiştirebilir.':''}`,'ok');render(); }
  function setSelectedDeleted(deleted){
    if(state.mode!=='legacy-scm')return;
    const selected=getChannels().filter(ch=>state.selected.has(currentKey(ch)));
    if(!selected.length)return;
    if(deleted && selected.filter(ch=>!ch.deletedByEditor).length>=normalChannels().length){setStatus('Listedeki tüm kanallar aynı anda silinemez.','error');return;}
    if(deleted){
      selected.forEach(ch=>{if(!ch.deletedByEditor)ch.deletedByEditor=true;});
      renumberUi(normalChannels()); setSourceSequenceDirty(state.sourceName,true);
    } else {
      let next=normalChannels().length+1;
      selected.forEach(ch=>{if(ch.deletedByEditor){ch.deletedByEditor=false;ch.uiOrder=next++;}});
      renumberUi(normalChannels()); setSourceSequenceDirty(state.sourceName,true);
    }
    state.selected.clear(); setStatus(`${selected.length} kanal ${deleted?'SCM listesinden silinmek':'geri getirilmek'} üzere işaretlendi.`,'ok');render();
  }
  function updateSelectAllState(){ const selectable=visibleChannels().filter(ch=>!isSystemChannel(ch)); const selected=selectable.filter(ch=>state.selected.has(currentKey(ch))).length; els.selectAll.checked=selectable.length>0&&selected===selectable.length; els.selectAll.indeterminate=selected>0&&selected<selectable.length; }
  function resetAll(){
    const sources=state.mode==='modern'?['tkgs','dvbs']:Object.keys(state.legacy.sources);
    for(const source of sources){ for(const ch of getChannels(source)){ch.srvName=ch.originalName;ch.hiddenByEditor=ch.originalHidden;ch.deletedByEditor=Boolean(ch.originalDeleted);ch.uiOrder=ch.originalUiOrder;} setSourceSequenceDirty(source,false); }
    state.selected.clear(); els.verification.classList.add('hidden'); els.verification.textContent=''; setStatus('Tüm planlanan değişiklikler geri alındı.','info'); render();
  }

  // ---------- Modern writer / verifier ----------
  function createModernWorkingDb(source){ return new state.SQL.Database(copyBytes(state.modern.originalBytes[source])); }
  function applyModernPlan(source,db){
    const channels=state.modern.channels[source], sequenceDirty=state.modern.sequenceDirty[source], changed=channels.filter(ch=>channelChangedFor(source,ch));
    if(!sequenceDirty&&!changed.length)return {changed:false,orderWritten:0,names:0,hidden:0};
    const orderTargets=normalChannels(source); db.run('BEGIN TRANSACTION');
    try{
      if(sequenceDirty){ orderTargets.forEach((ch,idx)=>db.run('UPDATE SRV SET major=? WHERE CAST(srvId AS TEXT)=?',[-1000000-idx,ch.srvKey])); orderTargets.forEach(ch=>db.run('UPDATE SRV SET major=?, modifiedByUser=1 WHERE CAST(srvId AS TEXT)=?',[ch.uiOrder,ch.srvKey])); }
      let names=0,hidden=0;
      for(const ch of changed){
        if(ch.srvName!==ch.originalName){db.run('UPDATE SRV SET srvName=?, modifiedByUser=1 WHERE CAST(srvId AS TEXT)=?',[swapUtf16Bytes(ch.srvName),ch.srvKey]);names++;}
        if(ch.hiddenByEditor!==ch.originalHidden){ if(ch.hiddenByEditor)db.run('UPDATE SRV SET hidden=1, hideGuide=1, numSel=0, modifiedByUser=1 WHERE CAST(srvId AS TEXT)=?',[ch.srvKey]); else db.run('UPDATE SRV SET hidden=0, hideGuide=0, numSel=1, modifiedByUser=1 WHERE CAST(srvId AS TEXT)=?',[ch.srvKey]); hidden++; }
      }
      db.run('COMMIT'); return {changed:true,orderWritten:sequenceDirty?orderTargets.length:0,names,hidden};
    }catch(err){try{db.run('ROLLBACK');}catch(_){} throw err;}
  }
  function verifyModernDb(source,db,exportedBytes){
    const errors=[],checks=[],channels=state.modern.channels[source],isTkgs=source==='tkgs';
    if(sourceHasChanges(source)){if(bytesEqual(exportedBytes,state.modern.originalBytes[source]))errors.push(`${source}: SQLite çıktısı orijinal dosyayla byte-byte aynı kaldı.`);else checks.push(`${source}: SQLite dosyası gerçekten değişti`);}
    if(state.modern.sequenceDirty[source]){
      const expected=normalChannels(source),rows=queryObjects(db,'SELECT CAST(srvId AS TEXT) AS srvKey,major FROM SRV'),map=new Map(rows.map(r=>[String(r.srvKey),r]));
      for(const ch of expected){const row=map.get(ch.srvKey);if(!row||Number(row.major)!==Number(ch.uiOrder))errors.push(`${source}: ${ch.srvName} beklenen ${ch.uiOrder}, DB ${row?.major??'yok'}`);}
      const majors=expected.map(ch=>Number(map.get(ch.srvKey)?.major)); if(!majors.every((n,i)=>n===i+1))errors.push(`${source}: aktif kanal numaraları 1..N değil.`);else checks.push(`${source}: ${expected.length} kanal 1..N sırasıyla doğrulandı`);
    }
    for(const ch of channels.filter(c=>c.srvName!==c.originalName)){const row=queryObjects(db,'SELECT srvName FROM SRV WHERE CAST(srvId AS TEXT)=?',[ch.srvKey])[0];const actual=cleanSamsungText(row?.srvName);if(actual!==ch.srvName)errors.push(`${source}: kanal adı doğrulanamadı (${ch.srvName} ≠ ${actual})`);else checks.push(`${source}: “${ch.srvName}” adı doğrulandı`);}
    for(const ch of channels.filter(c=>c.hiddenByEditor!==c.originalHidden)){const row=queryObjects(db,'SELECT hidden,hideGuide,numSel,elim,mem FROM SRV WHERE CAST(srvId AS TEXT)=?',[ch.srvKey])[0];const ok=ch.hiddenByEditor?Number(row?.hidden)===1&&Number(row?.hideGuide)===1&&Number(row?.numSel)===0:Number(row?.hidden)===0&&Number(row?.hideGuide)===0&&Number(row?.numSel)===1;if(!ok)errors.push(`${source}: ${ch.srvName} gizleme bayrakları beklenen durumda değil.`);} if(channels.some(c=>c.hiddenByEditor!==c.originalHidden))checks.push(`${source}: gizleme bayrakları doğrulandı`);
    for(const ch of channels.filter(c=>modernIsSystem(source,c))){const row=queryObjects(db,'SELECT major FROM SRV WHERE CAST(srvId AS TEXT)=?',[ch.srvKey])[0];if(Number(row?.major)!==Number(ch.originalMajor))errors.push(`${source}: sistem servisi ${ch.srvName} numarası değişti.`);}
    if(isTkgs){const rows=queryObjects(db,'SELECT CAST(d.srvId AS TEXT) AS srvKey,d.lcn,so.tkgsSrvLocator FROM SRV_DVB d LEFT JOIN SRV_SO so ON so.srvId=d.srvId'),map=new Map(rows.map(r=>[String(r.srvKey),r]));for(const ch of channels){const row=map.get(ch.srvKey);if(!row)continue;if(Number(row.lcn)!==Number(ch.lcn)||Number(row.tkgsSrvLocator)!==Number(ch.tkgsSrvLocator)){errors.push(`tkgs: ${ch.srvName} LCN/locator metadata değişti.`);break;}}if(!errors.some(e=>e.includes('LCN/locator')))checks.push('tkgs: LCN ve tkgsSrvLocator değerleri korundu');}
    return {errors,checks};
  }
  async function buildModernOutput(){
    const work={dvbs:createModernWorkingDb('dvbs'),tkgs:createModernWorkingDb('tkgs')};
    try{
      const stats={dvbs:applyModernPlan('dvbs',work.dvbs),tkgs:applyModernPlan('tkgs',work.tkgs)}, exported={dvbs:work.dvbs.export(),tkgs:work.tkgs.export()};
      for(const s of ['dvbs','tkgs']){const db=new state.SQL.Database(exported[s]);try{const v=verifyModernDb(s,db,exported[s]);if(v.errors.length)throw new Error(`SQLite doğrulaması başarısız:\n${v.errors.join('\n')}`);}finally{db.close();}}
      const outZip=await JSZip.loadAsync(copyBytes(state.archiveBytes)); outZip.file('dvbs',exported.dvbs); outZip.file('tkgs',exported.tkgs);
      const finalBytes=await outZip.generateAsync({type:'uint8array',compression:'DEFLATE',compressionOptions:{level:6}}), reopened=await JSZip.loadAsync(finalBytes), checks=[];
      for(const s of ['dvbs','tkgs']){const b=new Uint8Array(await reopened.file(s).async('arraybuffer')),db=new state.SQL.Database(b);try{const v=verifyModernDb(s,db,b);if(v.errors.length)throw new Error(`Final ZIP doğrulaması başarısız:\n${v.errors.join('\n')}`);checks.push(...v.checks);}finally{db.close();}}
      return {finalBytes,stats,checks,fileName:state.fileName.replace(/\.zip$/i,'')+'-edited-v063.zip'};
    } finally {work.dvbs.close();work.tkgs.close();}
  }

  // ---------- Legacy SCM writer / verifier ----------
  function setLegacyDeleteFlag(bytes,base,p,deleted){
    if(p.deleteMode==='deletedBit' && p.deletedOffset!=null){
      if(deleted) bytes[base+p.deletedOffset]|=p.deletedMask; else bytes[base+p.deletedOffset]&=(~p.deletedMask)&0xff;
      return true;
    }
    if(p.deleteMode==='clearInUse' && p.inUseOffset!=null){
      if(deleted) bytes[base+p.inUseOffset]&=(~p.inUseMask)&0xff; else bytes[base+p.inUseOffset]|=p.inUseMask;
      return true;
    }
    return false;
  }
  function legacyDeleteFlagMatches(bytes,base,p,deleted){
    if(p.deleteMode==='deletedBit' && p.deletedOffset!=null) return (((bytes[base+p.deletedOffset]&p.deletedMask)!==0)===deleted);
    if(p.deleteMode==='clearInUse' && p.inUseOffset!=null) return (((bytes[base+p.inUseOffset]&p.inUseMask)===0)===deleted);
    return !deleted;
  }
  function applyLegacyPlanToMap(source){
    const L=legacySource(source),p=L.profile,out=copyBytes(L.originalMapBytes),changed=L.channels.filter(ch=>channelChangedFor(source,ch)),touched=new Set();
    if(L.sequenceDirty){ for(const ch of normalChannels(source)){const base=ch.recordIndex*p.recordSize;writeU16LE(out,base+p.numberOffset,ch.uiOrder);touched.add(ch.recordIndex);} }
    let names=0,deletions=0;
    for(const ch of changed){
      const base=ch.recordIndex*p.recordSize;
      if(!ch.deletedByEditor&&ch.srvName!==ch.originalName){encodeUtf16BEInto(out,base+p.nameOffset,p.nameBytes,ch.srvName);touched.add(ch.recordIndex);names++;}
      if(Boolean(ch.deletedByEditor)!==Boolean(ch.originalDeleted)){if(!setLegacyDeleteFlag(out,base,p,Boolean(ch.deletedByEditor)))throw new Error(`${L.mapName}: bu record profili için güvenli silme alanı tanımlı değil.`);touched.add(ch.recordIndex);deletions++;}
    }
    for(const rec of touched) writeLegacyChecksum(out,rec*p.recordSize,p);
    return {bytes:out,stats:{orderWritten:L.sequenceDirty?normalChannels(source).length:0,names,deleted:deletions,checksums:touched.size}};
  }
  function verifyLegacyMap(source,mapBytes){
    const L=legacySource(source),p=L.profile,errors=[],checks=[];
    if(sourceHasChanges(source)){if(bytesEqual(mapBytes,L.originalMapBytes))errors.push(`${L.mapName}: byte-byte aynı kaldı.`);else checks.push(`${L.mapName}: gerçekten değişti`);}
    if(L.sequenceDirty){for(const ch of normalChannels(source)){const actual=readU16LE(mapBytes,ch.recordIndex*p.recordSize+p.numberOffset);if(actual!==ch.uiOrder)errors.push(`${L.mapName}: ${ch.srvName} beklenen ${ch.uiOrder}, kayıt ${actual}`);}if(!errors.length)checks.push(`${L.mapName}: ${normalChannels(source).length} aktif kanal sırası doğrulandı`);}
    for(const ch of L.channels.filter(c=>!c.deletedByEditor&&c.srvName!==c.originalName)){const actual=decodeUtf16BE(mapBytes,ch.recordIndex*p.recordSize+p.nameOffset,p.nameBytes);if(actual!==ch.srvName)errors.push(`${L.mapName}: kanal adı doğrulanamadı (${ch.srvName} ≠ ${actual})`);else checks.push(`${L.mapName}: “${ch.srvName}” adı doğrulandı`);}
    const deletedChanged=L.channels.filter(c=>Boolean(c.deletedByEditor)!==Boolean(c.originalDeleted));
    for(const ch of deletedChanged){const base=ch.recordIndex*p.recordSize;if(!legacyDeleteFlagMatches(mapBytes,base,p,Boolean(ch.deletedByEditor)))errors.push(`${L.mapName}: ${ch.srvName} silme durumu doğrulanamadı.`);}
    if(deletedChanged.length&&!errors.length)checks.push(`${L.mapName}: ${deletedChanged.filter(c=>c.deletedByEditor).length} kanal silme bayrağı doğrulandı`);
    const renamed=new Set(L.channels.filter(c=>!c.deletedByEditor&&c.srvName!==c.originalName).map(c=>c.recordIndex));
    const deletionRecords=new Set(deletedChanged.map(c=>c.recordIndex));
    for(let rec=0;rec<L.recordCount;rec++){
      const base=rec*p.recordSize;
      for(let off=0;off<p.recordSize;off++){
        const abs=base+off;if(mapBytes[abs]===L.originalMapBytes[abs])continue;
        const numberAllowed=off>=p.numberOffset&&off<p.numberOffset+p.numberLength;
        const nameAllowed=renamed.has(rec)&&off>=p.nameOffset&&off<p.nameOffset+p.nameBytes;
        const deleteAllowed=deletionRecords.has(rec)&&((p.deletedOffset!=null&&off===p.deletedOffset)||(p.deleteMode==='clearInUse'&&p.inUseOffset!=null&&off===p.inUseOffset));
        const checksumAllowed=p.checksumOffset!=null&&off===p.checksumOffset;
        if(!numberAllowed&&!nameAllowed&&!deleteAllowed&&!checksumAllowed){errors.push(`${L.mapName} güvenlik kontrolü: record ${rec}, offset ${off} beklenmeyen şekilde değişti.`);return {errors,checks};}
      }
    }
    if(p.checksumOffset!=null){
      const touched=new Set(); if(L.sequenceDirty)normalChannels(source).forEach(c=>touched.add(c.recordIndex)); L.channels.filter(c=>c.srvName!==c.originalName||Boolean(c.deletedByEditor)!==Boolean(c.originalDeleted)).forEach(c=>touched.add(c.recordIndex));
      for(const rec of touched){const base=rec*p.recordSize,expected=legacyChecksum(mapBytes,base,p.recordSize),actual=mapBytes[base+p.checksumOffset];if(expected!==actual){errors.push(`${L.mapName} checksum hatası: record ${rec}, beklenen ${expected}, kayıt ${actual}`);break;}}
      if(touched.size&&!errors.some(e=>e.includes('checksum')))checks.push(`${L.mapName}: değiştirilen record checksum değerleri doğrulandı`);
    }
    if(!errors.length)checks.push(`${L.mapName}: bilinmeyen record byte’ları korundu`);
    return {errors,checks};
  }
  async function verifyOtherArchiveEntries(originalZip, finalZip, exceptNames){
    const except=new Set(exceptNames), errors=[]; const names=Object.keys(originalZip.files).filter(n=>!originalZip.files[n].dir&&!except.has(n));
    for(const name of names){const a=new Uint8Array(await originalZip.file(name).async('arraybuffer')),bFile=finalZip.file(name);if(!bFile){errors.push(`SCM: arşiv girdisi kayboldu: ${name}`);continue;}const b=new Uint8Array(await bFile.async('arraybuffer'));if(!bytesEqual(a,b))errors.push(`SCM: ${name} içeriği beklenmedik şekilde değişti.`);}
    return errors;
  }
  async function buildLegacyOutput(){
    const changedSources=Object.keys(state.legacy.sources).filter(sourceHasChanges), generated={}, stats={}, checks=[];
    for(const source of changedSources){const r=applyLegacyPlanToMap(source),v=verifyLegacyMap(source,r.bytes);if(v.errors.length)throw new Error(`SCM doğrulaması başarısız:
${v.errors.join('\n')}`);generated[source]=r.bytes;stats[source]=r.stats;checks.push(...v.checks);}
    const outZip=await JSZip.loadAsync(copyBytes(state.archiveBytes));for(const source of changedSources)outZip.file(legacySource(source).mapName,generated[source]);
    const finalBytes=await outZip.generateAsync({type:'uint8array',compression:'DEFLATE',compressionOptions:{level:6}}),reopened=await JSZip.loadAsync(finalBytes);
    for(const source of changedSources){const L=legacySource(source),finalMap=new Uint8Array(await reopened.file(L.mapName).async('arraybuffer')),v=verifyLegacyMap(source,finalMap);if(v.errors.length)throw new Error(`Final SCM doğrulaması başarısız:
${v.errors.join('\n')}`);checks.push(...v.checks);}
    const originalZip=await JSZip.loadAsync(copyBytes(state.archiveBytes)),changedMapNames=changedSources.map(s=>legacySource(s).mapName),otherErrors=await verifyOtherArchiveEntries(originalZip,reopened,changedMapNames);if(otherErrors.length)throw new Error(`Final SCM doğrulaması başarısız:
${otherErrors.join('\n')}`);
    checks.push(`SCM: değiştirilmeyen ${Object.keys(originalZip.files).filter(n=>!originalZip.files[n].dir&&!changedMapNames.includes(n)).length} arşiv girdisi içerik olarak korundu`);
    return {finalBytes,stats,checks,fileName:state.fileName.replace(/\.scm$/i,'')+'-edited-v063.scm'};
  }

  async function exportCurrent(){
    if(!state.archive||totalChanges()===0)return; els.exportFile.disabled=true;els.verification.classList.add('hidden');setStatus('Değişiklikler yazılıyor ve final dosya yeniden açılarak doğrulanıyor…','info');
    try{
      const result=state.mode==='modern'?await buildModernOutput():await buildLegacyOutput();
      const mime='application/zip';downloadBlob(new Blob([result.finalBytes],{type:mime}),result.fileName);
      let statLine=''; if(state.mode==='modern')statLine=`• DVB-S: ${result.stats.dvbs.orderWritten} sıra, ${result.stats.dvbs.names} ad, ${result.stats.dvbs.hidden} gizleme<br>• TKGS: ${result.stats.tkgs.orderWritten} sıra, ${result.stats.tkgs.names} ad, ${result.stats.tkgs.hidden} gizleme`;else statLine=Object.entries(result.stats).map(([src,x])=>`• ${escapeHtml(legacySource(src).mapName)}: ${x.orderWritten} sıra, ${x.names} kanal adı, ${x.checksums||0} checksum`).join('<br>');
      els.verification.innerHTML=`<strong>Export doğrulandı ✓</strong><br>${result.checks.map(x=>`• ${escapeHtml(x)}`).join('<br>')}<br>${statLine}`;els.verification.classList.remove('hidden');setStatus(`${state.mode==='modern'?'ZIP':'SCM'} başarıyla oluşturuldu ve yeniden açılarak doğrulandı.`,'ok');
    }catch(err){console.error(err);els.verification.textContent=String(err.message||err);els.verification.classList.remove('hidden');setStatus('Export doğrulaması başarısız olduğu için dosya indirilmedi. Ayrıntı aşağıda.','error');}
    finally{updateChangeUi();}
  }

  // ---------- Open / detect ----------
  async function ensureJsZip(){if(typeof JSZip==='undefined')throw new Error('JSZip yüklenemedi. İlk açılışta internet bağlantısı gerekiyor.');}
  async function ensureSql(){if(state.SQL)return;if(typeof initSqlJs!=='function')throw new Error('sql.js yüklenemedi. Modern Samsung formatı için ilk açılışta internet bağlantısı gerekiyor.');state.SQL=await initSqlJs();}
  function closeModernDbs(){for(const db of Object.values(state.modern.db))try{db?.close();}catch(_){}state.modern.db={tkgs:null,dvbs:null};}
  async function openChannelFile(file){
    setStatus('Dosya analiz ediliyor…','info');els.workspace.classList.add('hidden');els.verification.classList.add('hidden');els.formatInfo.classList.add('hidden');await ensureJsZip();
    const raw=new Uint8Array(await file.arrayBuffer());let zip;try{zip=await JSZip.loadAsync(raw);}catch(_){throw new Error('Dosya geçerli bir Samsung ZIP/SCM arşivi olarak açılamadı.');}
    const names=new Set(Object.keys(zip.files));
    const isModern=['dvbs','tkgs','sat','metadata.xml','db-tvs-chms-schema.sei'].every(n=>names.has(n));
    const isLegacy=names.has('CloneInfo')&&([...names].some(n=>/^map-(SateD|CableD|AirD)$/i.test(n)));
    closeModernDbs();state.archive=zip;state.archiveBytes=copyBytes(raw);state.fileName=file.name;state.selected.clear();els.search.value='';els.showHidden.checked=false;els.showSystem.checked=false;

    if(isModern){
      state.mode='modern';state.sourceName='tkgs';await ensureSql();
      const dvbsBytes=new Uint8Array(await zip.file('dvbs').async('arraybuffer')),tkgsBytes=new Uint8Array(await zip.file('tkgs').async('arraybuffer'));
      state.modern.originalBytes.dvbs=copyBytes(dvbsBytes);state.modern.originalBytes.tkgs=copyBytes(tkgsBytes);state.modern.db.dvbs=new state.SQL.Database(copyBytes(dvbsBytes));state.modern.db.tkgs=new state.SQL.Database(copyBytes(tkgsBytes));
      validateModernSchema(state.modern.db.dvbs,'dvbs');validateModernSchema(state.modern.db.tkgs,'tkgs');loadModernChannels('dvbs');loadModernChannels('tkgs');
      els.formatInfo.innerHTML=`<strong>Format:</strong> Modern Samsung SQLite / Tizen &nbsp;·&nbsp; <strong>Kaynaklar:</strong> TKGS + DVB-S &nbsp;·&nbsp; <strong>Dosya:</strong> ${escapeHtml(file.name)}`;
      els.fileInfo.textContent=`${file.name} · Modern Samsung SQLite formatı algılandı.`;setStatus(`Modern format açıldı: ${state.modern.channels.tkgs.length} TKGS, ${state.modern.channels.dvbs.length} DVB-S servis kaydı.`,'ok');
    } else if(isLegacy){
      state.mode='legacy-scm';state.legacy.sources={};
      const cloneBytes=new Uint8Array(await zip.file('CloneInfo').async('arraybuffer'));state.legacy.model=parseCloneInfo(cloneBytes);
      const cable=await addLegacySource(zip,'map-CableD','scm-cable'),sate=await addLegacySource(zip,'map-SateD','scm-sate'),air=await addLegacySource(zip,'map-AirD','scm-air');
      const sources=Object.keys(state.legacy.sources);if(!sources.length)throw new Error('Legacy Samsung SCM algılandı fakat desteklenen dijital map profili bulunamadı.');
      state.sourceName=cable?'scm-cable':sate?'scm-sate':sources[0];
      const details=sources.map(id=>{const L=legacySource(id);return `${L.mapName}: ${L.channels.length} kanal / ${L.recordCount}×${L.recordSize}`;}).join(' &nbsp;·&nbsp; ');
      els.formatInfo.innerHTML=`<strong>Format:</strong> Legacy Samsung SCM &nbsp;·&nbsp; <strong>TV:</strong> ${escapeHtml(state.legacy.model)} &nbsp;·&nbsp; ${details}`;
      els.fileInfo.textContent=`${file.name} · Legacy Samsung SCM multi-list formatı algılandı.`;setStatus(`Legacy SCM açıldı: ${sources.map(id=>`${legacySource(id).label} ${legacySource(id).channels.length}`).join(', ')} servis. Model: ${state.legacy.model}.`,'ok');
    } else {
      const legacyHints=[...names].filter(n=>/^map-|CloneInfo|SatDataBase/i.test(n));
      if(legacyHints.length)throw new Error(`Samsung Legacy arşivi algılandı ancak bu sürümde desteklenen dijital map yapısı bulunamadı. Bulunan ilgili girdiler: ${legacyHints.slice(0,8).join(', ')}`);
      throw new Error('Samsung kanal listesi formatı tanınamadı. Modern SQLite veya desteklenen Legacy SCM yapısı bulunamadı.');
    }

    els.formatInfo.classList.remove('hidden');updateModeUi();buildTabs();rebuildTypeFilter();els.workspace.classList.remove('hidden');render();
  }

  // ---------- Events ----------
  els.channelFile.addEventListener('change',async()=>{const file=els.channelFile.files?.[0];if(!file)return;try{await openChannelFile(file);}catch(err){console.error(err);setStatus(String(err.message||err),'error');els.fileInfo.textContent=file.name;els.workspace.classList.add('hidden');}});
  els.search.addEventListener('input',render);els.typeFilter?.addEventListener('change',render);els.showSystem.addEventListener('change',render);els.showHidden.addEventListener('change',render);els.normalizeOrder.addEventListener('click',normalizeOrder);els.hideSelected.addEventListener('click',()=>state.mode==='legacy-scm'?setSelectedDeleted(true):setSelectedHidden(true));els.restoreSelected.addEventListener('click',()=>state.mode==='legacy-scm'?setSelectedDeleted(false):setSelectedHidden(false));els.undoAll.addEventListener('click',resetAll);els.exportFile.addEventListener('click',exportCurrent);
  els.selectAll.addEventListener('change',()=>{for(const ch of visibleChannels().filter(c=>!isSystemChannel(c))){if(els.selectAll.checked)state.selected.add(currentKey(ch));else state.selected.delete(currentKey(ch));}render();});
})();
